#Assignment
This package returns smallest element from an array


